document.addEventListener("DOMContentLoaded", function() {
    // Formun submit eventini dinliyoruz.
    document.getElementById('restoranformu').addEventListener("submit", function(event) {
        event.preventDefault(); // Formun submit olayını engelliyoruz.

        // Form alanlarını kontrol etmek için değişkenler
        let isletmeIsim = document.getElementById('isletmeisim').value.trim();
        let sahipIsim = document.getElementById('sahipisim').value.trim();
        let sahipSoyisim = document.getElementById('sahipsoyisim').value.trim();
        let isletmeEmail = document.getElementById('isletmeEmail').value.trim();
        let isletmeTelno = document.getElementById('isletmetelno').value.trim();
        let restoranAdres = document.getElementById('RestoranAdres').value.trim();
        let ticariIletiOnay = document.getElementById('KontrolRes').checked;

        // Hata mesajlarını toplamak için bir dizi oluşturuyoruz.
        let errorMessages = [];

        // Alanlar boş bırakıldıysa veya uzunluk kurallarına uymuyorsa hata mesajlarını ekliyoruz.
        if (!isletmeIsim) {
            errorMessages.push("Restoran adı boş bırakılamaz.");
        }

        if (!sahipIsim) {
            errorMessages.push("Restoran sahibi ismi boş bırakılamaz.");
        } else if (sahipIsim.length >= 3) {
            errorMessages.push("İsminizi tam girin (en az 3 karakter).");
        }

        if (!sahipSoyisim) {
            errorMessages.push("Restoran sahibi soyismi boş bırakılamaz.");
        } else if (sahipSoyisim.length >= 2) {
            errorMessages.push("Soyisminizi tam girin (en az 2 karakter).");
        }

        if (!isletmeEmail) {
            errorMessages.push("Restoran email'i boş bırakılamaz.");
        }

        if (!isletmeTelno) {
            errorMessages.push("Telefon numarası boş bırakılamaz.");
        }

        if (!restoranAdres) {
            errorMessages.push("Restoran adresi boş bırakılamaz.");
        } else if (restoranAdres.length < 25) {
            errorMessages.push("Adresin daha anlaşılabilir olması için daha detaylı yazınız (en az 25 karakter).");
        }

        // Ticari iletiler için onay işaretlenmemişse uyarı ekliyoruz.
        if (!ticariIletiOnay) {
            errorMessages.push("Şartları kabul etmeniz gerekiyor.");
        }

        // Eğer hata mesajları varsa alert gösteriyoruz.
        if (errorMessages.length > 0) {
            alert(errorMessages.join("\n"));
        } else {
            // Tüm koşullar sağlanıyorsa başarılı olduğuna dair bir mesaj gösteriyoruz.
            alert("Restoran kaydı başarıyla oluşturuldu!");
        }
    });
});
