document.addEventListener("DOMContentLoaded", function() {
    // 'rezervasyonformu' id'li formun submit eventini dinliyoruz.
    document.getElementById('rezervasyonformu').addEventListener("submit", function(event) {
        event.preventDefault(); // Formun submit olayını engelliyoruz.

        // Form alanlarını kontrol etmek için değişkenler
        let musteriIsim = document.getElementById('musteriisim').value.trim();
        let musteriSoyisim = document.getElementById('musterisoyisim').value.trim();
        let musteriEmail = document.getElementById('musteriEmail').value.trim();
        let musteriTelno = document.getElementById('musteritelno').value.trim();
        let restoranSecimi = document.getElementById('restorans').value;
        let tarihSecimi = document.getElementById('tarihSec').value;
        let saatSecimi = document.getElementById('saatSec').value;
        let ticariIletiOnay = document.getElementById('KontrolRez').checked;

        // Hata mesajlarını toplamak için bir dizi oluşturuyoruz.
        let errorMessages = [];

        // İsim alanının 3 karakterden kısa olup olmadığını kontrol ediyoruz.
        if (musteriIsim.length < 3) {
            errorMessages.push("İsminizi tam girin (en az 3 karakter).");
        }
        if (musteriSoyisim.length < 2) {
            errorMessages.push("Soyisminizi tam girin (en az 2 karakter).");
        }
        if (!musteriEmail) {
            errorMessages.push("Email alanı boş bırakılamaz.");
        }
        if (!musteriTelno) {
            errorMessages.push("Telefon numarası boş bırakılamaz.");
        }

        // Restoran seçimi yapılmadıysa uyarı ekliyoruz.
        if (restoranSecimi === "Restoran Seçiniz") {
            errorMessages.push("Bir restoran seçmelisiniz.");
        }

        // Tarih ve saat seçimi yapılmazsa uyarı ekliyoruz.
        if (!tarihSecimi) {
            errorMessages.push("Bir tarih seçmelisiniz.");
        }
        if (!saatSecimi) {
            errorMessages.push("Bir saat seçmelisiniz.");
        }

        // Ticari iletiler için onay işaretlenmemişse uyarı ekliyoruz.
        if (!ticariIletiOnay) {
            errorMessages.push("Şartları kabul etmeniz gerekiyor.");
        }

        // Eğer hata mesajları varsa alert gösteriyoruz.
        if (errorMessages.length > 0) {
            alert(errorMessages.join("\n"));
        } else {
            // Tüm koşullar sağlanıyorsa başarılı olduğuna dair bir mesaj gösteriyoruz.
            alert("Rezervasyon başarıyla oluşturuldu!");
        }
    });
});
