window.onload = function() {
    // Local Storage'dan rezervasyonları al
    let rezervasyonlar = JSON.parse(localStorage.getItem('rezervasyonlar')) || [];

    // Tabloya rezervasyonları ekle
    const tablo = document.getElementById('rezervasyonlarTablosu');

    rezervasyonlar.forEach(function(rezervasyon) {
        let row = tablo.insertRow();

        let isimCell = row.insertCell(0);
        let soyisimCell = row.insertCell(1);
        let emailCell = row.insertCell(2);
        let telefonCell = row.insertCell(3);
        let restoranCell = row.insertCell(4);
        let tarihCell = row.insertCell(5);
        let saatCell = row.insertCell(6);

        isimCell.innerHTML = rezervasyon.isim;
        soyisimCell.innerHTML = rezervasyon.soyisim;
        emailCell.innerHTML = rezervasyon.email;
        telefonCell.innerHTML = rezervasyon.telefon;
        restoranCell.innerHTML = rezervasyon.restoran;
        tarihCell.innerHTML = rezervasyon.tarih;
        saatCell.innerHTML = rezervasyon.saat;
    });
};
