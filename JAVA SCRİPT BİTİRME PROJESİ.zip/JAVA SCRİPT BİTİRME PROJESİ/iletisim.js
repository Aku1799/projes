document.addEventListener("DOMContentLoaded", function() {
    // Formun submit eventini dinliyoruz.
    document.getElementById('iletisimformu').addEventListener("submit", function(event) {
        event.preventDefault(); // Formun submit olayını engelliyoruz.

        // Form alanlarını kontrol etmek için değişkenler
        let isim = document.getElementById('isim1').value.trim();
        let soyisim = document.getElementById('sisim1').value.trim();
        let email = document.getElementById('Email').value.trim();
        let telno = document.getElementById('telno').value.trim();
        let konu = document.getElementById('konu').value.trim();
        let mesaj = document.getElementById('mesajalani').value.trim();
        let ticariIletiOnay = document.getElementById('kontrolmsj').checked;

        // Hata mesajlarını toplamak için bir dizi oluşturuyoruz.
        let errorMessages = [];

        // Alanlar boş bırakıldıysa veya uzunluk kurallarına uymuyorsa hata mesajlarını ekliyoruz.
        if (!isim) {
            errorMessages.push("İsim boş bırakılamaz.");
        } else if (isim.length >= 3) {
            errorMessages.push("İsminizi tam girin (en az 3 karakter).");
        }

        if (!soyisim) {
            errorMessages.push("Soyisim boş bırakılamaz.");
        } else if (soyisim.length >= 2) {
            errorMessages.push("Soyisminizi tam girin (en az 2 karakter).");
        }

        if (!email) {
            errorMessages.push("Email boş bırakılamaz.");
        }

        if (!telno) {
            errorMessages.push("Telefon numarası boş bırakılamaz.");
        }

        if (!konu) {
            errorMessages.push("Konu başlığı boş bırakılamaz.");
        } else if (konu.length < 15) {
            errorMessages.push("Konuyu daha uzun belirtin (en az 15 karakter).");
        }

        if (!mesaj) {
            errorMessages.push("Mesaj boş bırakılamaz.");
        } else if (mesaj.length < 70) {
            errorMessages.push("Mesajın daha anlaşılabilir olması için daha detaylı yazınız (en az 70 karakter).");
        }

        // Ticari iletiler için onay işaretlenmemişse uyarı ekliyoruz.
        if (!ticariIletiOnay) {
            errorMessages.push("Ticari elektronik iletilerin gönderilmesini kabul etmeniz gerekiyor.");
        }

        // Eğer hata mesajları varsa alert gösteriyoruz.
        if (errorMessages.length > 0) {
            alert(errorMessages.join("\n"));
        } else {
            // Tüm koşullar sağlanıyorsa başarılı olduğuna dair bir mesaj gösteriyoruz.
            alert("Mesajınız başarıyla gönderildi!");
        }
    });
});
